jQuery(document).ready(function() {

	jQuery(".fancyVideo").click(function() {
		jQuery.fancybox({
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'elastic',
				'width'			: 640,
				'height'		: 360,
				'href'			: this.href.replace(new RegExp("watch\\?v=", "i"), 'v/'),
				'type'			: 'swf',
				'swf'			: {
					'wmode'		: 'transparent',
					'allowfullscreen'	: 'true'
				}
			});

	return false;
	});
});

jQuery(document).ready(function() {

	jQuery("#panel-tab").toggle(fnShow, fnHide);
	return false;

});				

function fnShow() {

	jQuery('#voice-demo-text').val(voicedemo_vars.demotext);

	jQuery('#voice-demo-lang :selected').removeAttr('selected');
	jQuery('#voice-demo-lang').prop('selectedIndex', 0);
	jQuery('#vd-error-message').remove();
	jQuery('#voice-demo-submit').show();
	jQuery('#readspeaker-mini-player').hide();

	jQuery('#voice-demo-panel-text').val(voicedemo_vars.demotext);

	jQuery('#voice-demo-panel-lang :selected').removeAttr('selected');
	jQuery('#voice-demo-panel-lang').prop('selectedIndex', 0);
	jQuery('#vd-error-message').remove();
	jQuery('#voice-demo-panel-submit').show();
	jQuery('#readspeaker-panel-mini-player').hide();

	jQuery('#voice-demo-panel').animate({right: 0}, 1000);
	jQuery('#panel-tab').animate({right: 303}, 1000);
}

function fnHide() {
	jQuery('#voice-demo-panel').animate({right: -303}, 1000);
	jQuery('#panel-tab').animate({right: 0}, 1000);
}


	/*
	
	jQuery('#toggleButton_All').toggle(function() {
		var x = 38;
		var i = 1;
		
		while (i < x) {
			jQuery('#voices_' + i).show('slow');
			jQuery('#toggleButton_' + i).val('Close demo');
			i++;
		}
		jQuery(this).val('Close all demos');
	}, function() {
		var x = 38;
		var i = 1;
		
		while (i < x) {
			jQuery('#voices_' + i).hide('slow');
			jQuery('#toggleButton_' + i).val('Open demo');
			i++;
		}
		jQuery(this).val('Open all demos');
	});

	jQuery('#toggleButton_1').click(function() {
		jQuery('#voices_1').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_2').click(function() {
		jQuery('#voices_2').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_3').click(function() {
		jQuery('#voices_3').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_4').click(function() {
		jQuery('#voices_4').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_5').click(function() {
		jQuery('#voices_5').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_6').click(function() {
		jQuery('#voices_6').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_7').click(function() {
		jQuery('#voices_7').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_8').click(function() {
		jQuery('#voices_8').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_9').click(function() {
		jQuery('#voices_9').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_10').click(function() {
		jQuery('#voices_10').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_11').click(function() {
		jQuery('#voices_11').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_12').click(function() {
		jQuery('#voices_12').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_13').click(function() {
		jQuery('#voices_13').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_14').click(function() {
		jQuery('#voices_14').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_15').click(function() {
		jQuery('#voices_15').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_16').click(function() {
		jQuery('#voices_16').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_17').click(function() {
		jQuery('#voices_17').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_18').click(function() {
		jQuery('#voices_18').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_19').click(function() {
		jQuery('#voices_19').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_20').click(function() {
		jQuery('#voices_20').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_21').click(function() {
		jQuery('#voices_21').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_22').click(function() {
		jQuery('#voices_22').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_23').click(function() {
		jQuery('#voices_23').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_24').click(function() {
		jQuery('#voices_24').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_25').click(function() {
		jQuery('#voices_25').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_26').click(function() {
		jQuery('#voices_26').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_27').click(function() {
		jQuery('#voices_27').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_28').click(function() {
		jQuery('#voices_28').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_29').click(function() {
		jQuery('#voices_29').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_30').click(function() {
		jQuery('#voices_30').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_31').click(function() {
		jQuery('#voices_31').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_32').click(function() {
		jQuery('#voices_32').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_33').click(function() {
		jQuery('#voices_33').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_34').click(function() {
		jQuery('#voices_34').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_35').click(function() {
		jQuery('#voices_35').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_36').click(function() {
		jQuery('#voices_36').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	});
	
	jQuery('#toggleButton_37').click(function() {
		jQuery('#voices_37').toggle('slow');
		if (jQuery(this).val() == 'Close demo') {
			jQuery(this).val('Open demo');
		} else {
			jQuery(this).val('Close demo');
		}
	}); */


