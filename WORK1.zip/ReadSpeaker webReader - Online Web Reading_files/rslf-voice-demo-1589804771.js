(function($) {

	$('#readspeaker-mini-player').simplePlayer({
		labels: {
			play: voicedemo_vars.play,
			pause: voicedemo_vars.pause
		}
	});

	$('#voice-demo-text').on('click', function() {
		$(this).select();
	});

	$('#voice-demo-submit').on('click', function() {

		if ($('#voice-demo-lang')[0].selectedIndex === 0 || ! $('#voice-demo-text').val()) {
				if (! $('#vd-error-message').length) {
					$('#voice-demo-form').after(voicedemo_vars.errormsg);
				}
				return false;
			} else {
				$('#vd-error-message').remove();
			}

		var
		audioTagSupport = !!(document.createElement('audio').canPlayType),
		au = window.simpleAudio;

		if (audioTagSupport && typeof au !== 'object') {
			au = window.simpleAudio = new Audio();
			au.play()
			au.pause();
		}

		$.ajax('https://demo.readspeaker.com/proxy.php', {
			success: function(data) {
				$('#readspeaker-mini-player').show();
				$('#readspeaker-mini-player').simplePlayer('play', {
					flv: data.links.flv,
					mp3: data.links.mp3,
					ogg: data.links.ogg
				});
			},
			data: {
				v: $('#voice-demo-lang').val(),
				t: $('#voice-demo-text').val(),
				f: $('#readspeaker-mini-player').simplePlayer('audioformat')
			},
			dataType: 'json',
			type: 'post'

		});

		$(this).hide();

		return false;

	});

	$('#voice-demo-lang').change(function () {
		$('#vd-error-message').remove();
		$('#voice-demo-submit').show();
		$('#readspeaker-mini-player').hide();
	});

	$('#voice-demo-text').keyup(function () {
		$('#voice-demo-submit').show();
		$('#readspeaker-mini-player').hide();
	});

	$('#readspeaker-panel-mini-player').simplePlayer({
		labels: {
			play: voicedemo_vars.play,
			pause: voicedemo_vars.pause
		}
	});

	$('#voice-demo-panel-submit').on('click', function() {

		if ($('#voice-demo-panel-lang')[0].selectedIndex === 0 || ! $('#voice-demo-panel-text').val()) {
				if (! $('#vd-error-message').length) {
					$('#voice-demo-panel-form').after(voicedemo_vars.errormsg);
				}
				return false;
			} else {
				$('#vd-error-message').remove();
			}

		$.ajax('https://demo.readspeaker.com/proxy.php', {
			success: function(data) {
				$('#readspeaker-panel-mini-player').show();
				$('#readspeaker-panel-mini-player').simplePlayer('play', {
					flv: data.links.flv,
					mp3: data.links.mp3,
					ogg: data.links.ogg
				});
			},
			data: {
				v: $('#voice-demo-panel-lang').val(),
				t: $('#voice-demo-panel-text').val(),
				f: $('#readspeaker-panel-mini-player').simplePlayer('audioformat')
			},
			dataType: 'json',
			type: 'post'

		});

		$(this).hide();

		return false;

	});

	$('#voice-demo-panel-lang').change(function () {
		$('#vd-error-message').remove();
		$('#voice-demo-panel-submit').show();
		$('#readspeaker-panel-mini-player').hide();
	});

	$('#voice-demo-panel-text').keyup(function () {
		$('#voice-demo-panel-submit').show();
		$('#readspeaker-panel-mini-player').hide();
	});


})(jQuery);

rspkr.q(function() {

   rspkr.cfg.item('cb.ui.play', function() {
	  // Hide the button...
	  jQuery('#voice-demo-submit').hide();
	  jQuery('#voice-demo-panel-submit').hide();
   });

   rspkr.cfg.item('cb.ui.close', function() {
	  // Show the button...
	  jQuery('#voice-demo-submit').show();
	  jQuery('#voice-demo-panel-submit').show();
   });

});